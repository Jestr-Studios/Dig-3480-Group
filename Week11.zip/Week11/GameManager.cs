using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using TMPro;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class GameManager : MonoBehaviour
{

    public GameObject enemyOnePrefab;
    public GameObject enemyTwoPrefab;
    public GameObject enemyThreePrefab;
    public GameObject coinPrefab;
    public GameObject HealthPackPrefab;
    public TextMeshProUGUI livesText;
    public GameObject explosionPrefab;
    public int score;


    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("CreateEnemyOne", 1, 2);
        InvokeRepeating("CreateEnemyTwo", 1, 2);
        InvokeRepeating("CreateEnemyThree", 1, 2);
        InvokeRepeating("CreateCoin", 1, 2);
        InvokeRepeating("CreateHealthPack", 1, 2);
        score = 0;
    }

    // Update is called once per frame
    void Update()
    {
       
    }

    void CreateEnemyOne()
    {
        Instantiate(enemyOnePrefab, new Vector3(Random.Range(-9f, 9f), 6.5f, 0), Quaternion.identity);
    }

    void CreateEnemyTwo()
    {
        Instantiate(enemyTwoPrefab, new Vector3(Random.Range(-9f, 9f), -10f, 0), Quaternion.identity);
    }

    void CreateEnemyThree()
    {
        Instantiate(enemyThreePrefab, new Vector3(Random.Range(-9f, -8f), 0, 6.25f), Quaternion.identity);
    }

    void CreateCoin()
    {
        Instantiate(coinPrefab, new Vector3(Random.Range(-8, 8f), Random.Range(-2, 2f), 5f), Quaternion.identity); 
    }

    void CreateHealthPack()
    {
        Instantiate(HealthPackPrefab, new Vector3(Random.Range(-8, 8f), Random.Range(-2, 2f), 2f), Quaternion.identity);
    }
    public void AddScore(int earnedScore)
    {
        score = score + earnedScore;
    }

    public void ChangeLivesText(int currentLives)
    {
        livesText.text = "Lives: " + currentLives;
    }
}


